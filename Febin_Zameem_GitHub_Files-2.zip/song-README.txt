PAATT MAATTAN: puthiya paatt "song.m4a" ennu peru maatti ee folder-il idukka.
PERSONAL LINK: link-nte avasanam ?to=Ahmed ennu cherkkuka (e.g. https://site.netlify.app/?to=Ahmed).
WHATSAPP PREVIEW: Netlify link kittiyal, index.html-il og:image content="couple.jpg" ennathu poorna link aakkanam (https://site.netlify.app/couple.jpg).
